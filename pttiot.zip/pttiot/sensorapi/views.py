from django.shortcuts import render
from rest_framework import viewsets
from .models import Allsensorapi

from rest_framework.parsers import JSONParser
from django.http import JsonResponse


#####################
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .serializers import AllsensorapiSerializer
#####################

#### GET
@api_view(['GET',])
def api_get_detail_sensor(request, pk):
	try:
		allsensor = Allsensorapi.objects.get(id=pk)
	except Allsensorapi.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)

	if request.method == 'GET':
		serializer = AllsensorapiSerializer(allsensor)
		return Response(serializer.data)

#### PUT
@api_view(['PUT',])
def api_put_detail_sensor(request, pk):
	try:
		allsensor = Allsensorapi.objects.get(id=pk)
	except Allsensorapi.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)

	if request.method == 'PUT':
		serializer = AllsensorapiSerializer(allsensor, data=request.data)
		data = {}
		if serializer.is_valid():
			serializer.save()
			data['success'] = 'update successful'
			return Response(data=data)
		return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



#### DELETE
@api_view(['DELETE',])
def api_delete_detail_sensor(request, pk):
	try:
		allsensor = Allsensorapi.objects.get(id=pk)
	except Allsensorapi.DoesNotExist:
		return Response(status=status.HTTP_404_NOT_FOUND)

	if request.method == 'DELETE':
		operation = allsensor.delete()
		data = {}
		if operation:
			data['success'] = 'delete successful'
		else:
			data['failure'] = 'delete failed'
		return Response(data=data)


#### DELETE
@api_view(['POST',])
def api_post_detail_sensor(request):

	allsensor = Allsensorapi()
	if request.method == 'POST':
		serializer = AllsensorapiSerializer(data=request.data)
		if serializer.is_valid():
			serializer.save()
			return Response(serializer.data, status.HTTP_201_CREATED)
	return Response(serializer.errors, status=status.HTTP_404_NOT_FOUND)
	


##########OLD###########
def AllsensorapiView(request):

	if request.method == 'GET':
		allsensor = Allsensorapi.objects.all()
		serializer = AllsensorapiSerializer(allsensor, many=True)
		return JsonResponse(serializer.data, safe=False)

def AllsensorDetail(request,pk):

	allsensor = Allsensorapi.objects.get(id=pk)
	serializer = AllsensorapiSerializer(allsensor)
	return JsonResponse(serializer.data, safe=True)