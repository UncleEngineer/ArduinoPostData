#sensor/urls.py

from django.urls import path, include
from .views import (
	AllsensorapiView,
	AllsensorDetail,
	api_get_detail_sensor,
	api_post_detail_sensor,
	api_delete_detail_sensor,
	api_put_detail_sensor)
from rest_framework import routers

urlpatterns = [
    path('',AllsensorapiView),
    path('<int:pk>/',api_get_detail_sensor,name='detail'),
    path('<int:pk>/update',api_put_detail_sensor,name='update'),
    path('<int:pk>/delete',api_delete_detail_sensor,name='delete'),
    path('create',api_post_detail_sensor,name='create'),


    #path('<int:pk>/',AllsensorDetail)
]
