from django.apps import AppConfig


class SensorapiConfig(AppConfig):
    name = 'sensorapi'
