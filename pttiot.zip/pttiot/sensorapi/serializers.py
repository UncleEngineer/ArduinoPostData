from rest_framework import serializers
from .models import Allsensorapi

class AllsensorapiSerializer(serializers.ModelSerializer):
	class Meta:
		model = Allsensorapi
		fields = ('id','sensor_name','sensor_temp')