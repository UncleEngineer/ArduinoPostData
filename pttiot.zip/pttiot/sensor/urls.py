#sensor/urls.py

from django.urls import path
from .views import Home, SensorDetail

urlpatterns = [
    path('',Home,name='home-page'),
    path('sensor/<sensor_id>',SensorDetail, name='sensor-page')
]
