#sensorapi.py

import requests

#url = 'https://www.aismagellan.io/api/things/pull/5ce17850-90c8-11e9-96dd-9fb5d8a71344?fbclid=IwAR20WPPmgA-X_7kVN5BC4vUDOr71GQgPVis37yYlzdVOIi2j1LR37gwQZfE'

def GetDataSensor(url):

	req = requests.get(url)
	data = req.json()
	print(type(data))
	print(data['atmos'])
	print(data['clock'])
	print(data['PM'])
	return data