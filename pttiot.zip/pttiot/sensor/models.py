from django.db import models

# Create your models here.

class AllSensor(models.Model):

	sensor_name = models.CharField(max_length=100)
	sensor_location = models.CharField(max_length=100)
	sensor_detail = models.TextField(null=True, blank=True)
	sensor_api = models.CharField(max_length=500,null=True,blank=True)
	sensor_photo = models.ImageField(upload_to="sensor_photo",null=True,blank=True)

	def __str__(self):
		return self.sensor_name