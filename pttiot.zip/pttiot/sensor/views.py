from django.shortcuts import render
from django.http import HttpResponse
# Get Data from Models
from .models import AllSensor
from .sensorapi import GetDataSensor

def Home(request):
	text = 'We will show all sensor'
	#allsensor = ['1-Temp','2-Pressure','3-Power Meter']

	allsensor = AllSensor.objects.all()

	context = {'text':text,'allsensor':allsensor}
	return render(request, 'sensor/home.html',context)

def SensorDetail(request, sensor_id):
	single_sensor = AllSensor.objects.get(id=sensor_id)

	url = single_sensor.sensor_api

	data_sensor = GetDataSensor(url)

	# print(data['atmos'])
	# print(data['clock'])
	# print(data['PM'])

	context = {'single_sensor':single_sensor}
	context.update(data_sensor)

	return render(request, 'sensor/sensordetail.html', context)

