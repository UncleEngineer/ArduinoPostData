from django.contrib import admin
from .models import AllSensor
# Register your models here.

class DetailSensor(admin.ModelAdmin):
	list_display = ['sensor_name','sensor_location','sensor_detail']


admin.site.register(AllSensor, DetailSensor)