from django.shortcuts import render, redirect
from .forms import UserRegisterForm
# Create your views here.

def Register(request):
	if request.method == 'POST':
		form = UserRegisterForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('home-page')

	form = UserRegisterForm()
	context = {'form':form}
	return render(request,'user/register.html',context)